<?php

namespace Illuminate\Database;

class UniqueConstraintViolationException extends QueryException
{
}
